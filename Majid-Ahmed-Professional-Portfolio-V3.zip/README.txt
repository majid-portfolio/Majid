MAJID AHMED PORTFOLIO V3

WHAT'S NEW
- Upload your profile photo from Admin.
- Add portfolio projects with image/title/category/description.
- Remove portfolio projects.
- Upload a replacement CV PDF from Admin; homepage buttons use the new PDF.
- WhatsApp number is clickable and opens WhatsApp chat: +92 324 7900489.
- Start a Project section has WhatsApp, Email, Behance and CV icons.
- assets/icons contains editable SVG icons.
- Separate Behance portfolio link: https://www.behance.net/Majid-ahmed

ADMIN
Open admin.html
Password: Majid@2026

IMPORTANT
This ZIP is a static prototype. Admin changes are saved in the current browser using localStorage. For a real online site where you can update projects/CV/photo from any phone and every visitor sees the changes, connect the Admin panel to a cloud database/storage when deploying.
